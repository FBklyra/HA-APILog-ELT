#!/bin/sh
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
exec sh "$HERE/deploy/linux/uninstall.sh" "$@"
