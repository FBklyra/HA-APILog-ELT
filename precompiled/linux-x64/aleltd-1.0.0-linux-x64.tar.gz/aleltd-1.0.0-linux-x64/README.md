# aleltd 1.0.0 — ALELT Linux capture daemon (linux x64)

Pure-Python daemon (no compiled code). Requires Python >= 3.10 and systemd.

| Path | Content |
|---|---|
| `install.sh` / `uninstall.sh` | installer wrappers (`deploy/linux/install.sh`) |
| `alelt.service` | systemd unit (installed by `install.sh` to `/etc/systemd/system/`) |
| `edge-agent/linux/aleltd` | the daemon |
| `wheels/` | per-engine minimal wheels (`pip install alelt_agentd_<engine>-*.whl`) as an alternative to `install.sh` |
| `deploy/linux/aleltagent.example.json`, `agent.env.example` | configuration templates (copied to `/etc/alelt`) |

Quick start:

```sh
tar xzf aleltd-1.0.0-linux-x64.tar.gz && cd aleltd-1.0.0-linux-x64
sudo ./install.sh --engines postgres --no-start
sudoedit /etc/alelt/aleltagent.json        # hub URL, agent id, connection, source settings
sudoedit /etc/alelt/agent.env              # agent token (ALELT_AGENT_TOKEN) or mTLS settings
sudo systemctl start alelt.service && journalctl -u alelt.service -f
```

See `deploy/linux/README.md` and `KNOWN-ISSUES.md`.
