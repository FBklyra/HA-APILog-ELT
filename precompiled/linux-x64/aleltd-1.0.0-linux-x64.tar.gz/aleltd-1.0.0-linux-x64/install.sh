#!/bin/sh
# ALELT Linux capture daemon (aleltd) installer: systemd service alelt.service, code in /opt/alelt, state in /var/lib/alelt.
#   sudo ./install.sh --engines postgres          (agent only; engines: postgres mysql mariadb sqlserver oracle)
#   sudo ./install.sh --help                      (all options, incl. --hub / --all for a hub without Docker)
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
exec sh "$HERE/deploy/linux/install.sh" --src "$HERE" "$@"
